package com.vsmovie.app;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.graphics.Color;
import android.graphics.drawable.GradientDrawable;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.view.WindowManager;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceRequest;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.TextView;

import org.json.JSONArray;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * Trình phát toàn màn hình. Nguồn phim của vsmov là một trang "embed" (link_embed)
 * nên ta mở nó trong WebView riêng, có nút quay lại / tập trước / tập sau.
 */
public class PlayerActivity extends Activity {

    private FrameLayout root;
    private WebView web;
    private View customView;
    private WebChromeClient.CustomViewCallback customCallback;
    private WebChromeClient chrome;

    private LinearLayout bar;
    private TextView titleView;
    private final Handler handler = new Handler(Looper.getMainLooper());
    private final Runnable hideBar = new Runnable() {
        @Override
        public void run() {
            if (bar != null) bar.setVisibility(View.GONE);
        }
    };

    private String movieTitle = "";
    private final List<String> epNames = new ArrayList<String>();
    private final List<String> epEmbeds = new ArrayList<String>();
    private final List<String> epM3u8 = new ArrayList<String>();
    private int index = 0;
    private String allowedHost = "";

    @SuppressLint({"SetJavaScriptEnabled", "ClickableViewAccessibility"})
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
        if (Build.VERSION.SDK_INT >= 28) {
            getWindow().getAttributes().layoutInDisplayCutoutMode =
                    WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_SHORT_EDGES;
        }

        parsePayload(getIntent().getStringExtra("payload"));

        root = new FrameLayout(this);
        root.setBackgroundColor(Color.BLACK);

        web = new WebView(this);
        web.setBackgroundColor(Color.BLACK);
        root.addView(web, new FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));

        WebSettings s = web.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setMediaPlaybackRequiresUserGesture(false);
        s.setSupportMultipleWindows(false);
        s.setJavaScriptCanOpenWindowsAutomatically(false);
        s.setMixedContentMode(WebSettings.MIXED_CONTENT_ALWAYS_ALLOW);
        s.setLoadWithOverviewMode(true);
        s.setUseWideViewPort(true);

        chrome = new WebChromeClient() {
            @Override
            public void onShowCustomView(View view, CustomViewCallback callback) {
                if (customView != null) {
                    callback.onCustomViewHidden();
                    return;
                }
                customView = view;
                customCallback = callback;
                root.addView(view, 0, new FrameLayout.LayoutParams(
                        ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));
                web.setVisibility(View.GONE);
                hideSystemUi();
            }

            @Override
            public void onHideCustomView() {
                if (customView == null) return;
                root.removeView(customView);
                customView = null;
                web.setVisibility(View.VISIBLE);
                if (customCallback != null) customCallback.onCustomViewHidden();
                customCallback = null;
                hideSystemUi();
            }

            @Override
            public boolean onCreateWindow(WebView view, boolean isDialog, boolean isUserGesture,
                                          android.os.Message resultMsg) {
                // Chặn popup quảng cáo
                return false;
            }
        };
        web.setWebChromeClient(chrome);

        web.setWebViewClient(new WebViewClient() {
            @Override
            public boolean shouldOverrideUrlLoading(WebView view, WebResourceRequest request) {
                String u = request.getUrl().toString();
                String host = request.getUrl().getHost();
                if (host == null) return true;
                boolean ok = u.startsWith("about:") || u.startsWith("data:")
                        || host.equals(allowedHost)
                        || host.endsWith("streamvsmov.com")
                        || host.endsWith("vsmov.com");
                // Cho phép trình phát tự chuyển trong cùng nhà cung cấp, chặn quảng cáo bên ngoài.
                return !ok;
            }
        });

        web.setOnTouchListener(new View.OnTouchListener() {
            @Override
            public boolean onTouch(View v, MotionEvent event) {
                if (event.getAction() == MotionEvent.ACTION_DOWN) showBar();
                return false; // không chặn thao tác của trình phát
            }
        });

        buildBar();
        setContentView(root);
        hideSystemUi();
        loadCurrent();
        showBar();
    }

    private void parsePayload(String json) {
        try {
            JSONObject o = new JSONObject(json == null ? "{}" : json);
            movieTitle = o.optString("title", "");
            index = o.optInt("index", 0);
            JSONArray arr = o.optJSONArray("episodes");
            if (arr != null) {
                for (int i = 0; i < arr.length(); i++) {
                    JSONObject e = arr.getJSONObject(i);
                    epNames.add(e.optString("name", ""));
                    epEmbeds.add(e.optString("embed", ""));
                    epM3u8.add(e.optString("m3u8", ""));
                }
            }
        } catch (Exception ignored) {
        }
        if (index < 0 || index >= epNames.size()) index = 0;
    }

    private TextView makeBtn(String text) {
        TextView t = new TextView(this);
        t.setText(text);
        t.setTextColor(Color.WHITE);
        t.setTextSize(14);
        t.setGravity(Gravity.CENTER);
        t.setPadding(dp(14), dp(8), dp(14), dp(8));
        GradientDrawable bg = new GradientDrawable();
        bg.setColor(Color.parseColor("#66000000"));
        bg.setCornerRadius(dp(18));
        t.setBackground(bg);
        return t;
    }

    private void buildBar() {
        bar = new LinearLayout(this);
        bar.setOrientation(LinearLayout.HORIZONTAL);
        bar.setGravity(Gravity.CENTER_VERTICAL);
        bar.setPadding(dp(12), dp(8), dp(12), dp(8));

        TextView back = makeBtn("‹  Quay lại");
        back.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finish();
            }
        });
        bar.addView(back);

        titleView = new TextView(this);
        titleView.setTextColor(Color.WHITE);
        titleView.setTextSize(15);
        titleView.setSingleLine(true);
        titleView.setPadding(dp(12), 0, dp(12), 0);
        LinearLayout.LayoutParams tp = new LinearLayout.LayoutParams(0,
                ViewGroup.LayoutParams.WRAP_CONTENT, 1f);
        bar.addView(titleView, tp);

        if (epNames.size() > 1) {
            TextView prev = makeBtn("‹ Tập trước");
            prev.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    go(index - 1);
                }
            });
            TextView next = makeBtn("Tập sau ›");
            next.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    go(index + 1);
                }
            });
            LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(
                    ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT);
            lp.leftMargin = dp(8);
            bar.addView(prev, lp);
            bar.addView(next, lp);
        }

        FrameLayout.LayoutParams fp = new FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT,
                Gravity.TOP);
        root.addView(bar, fp);
    }

    private void go(int i) {
        if (i < 0 || i >= epNames.size()) return;
        index = i;
        loadCurrent();
        MainActivity.notifyEpisode(index);
        showBar();
    }

    private void loadCurrent() {
        String name = index < epNames.size() ? epNames.get(index) : "";
        titleView.setText(name.length() > 0 ? movieTitle + "  •  " + name : movieTitle);

        String embed = index < epEmbeds.size() ? epEmbeds.get(index) : "";
        String m3u8 = index < epM3u8.size() ? epM3u8.get(index) : "";

        if (embed != null && embed.length() > 0 && !"null".equals(embed)) {
            allowedHost = hostOf(embed);
            Map<String, String> headers = new HashMap<String, String>();
            headers.put("Referer", "https://vsmov.com/");
            web.loadUrl(embed, headers);
        } else if (m3u8 != null && m3u8.length() > 0 && !"null".equals(m3u8)) {
            allowedHost = hostOf(m3u8);
            String html = "<html><body style='margin:0;background:#000'>"
                    + "<video src='" + m3u8.replace("'", "%27") + "' controls autoplay playsinline "
                    + "style='width:100%;height:100vh;background:#000'></video></body></html>";
            web.loadDataWithBaseURL("https://vsmov.com/", html, "text/html", "utf-8", null);
        } else {
            String html = "<html><body style='margin:0;background:#000;color:#bbb;"
                    + "font-family:sans-serif;display:flex;align-items:center;justify-content:center;"
                    + "height:100vh'>Tập này chưa có nguồn phát.</body></html>";
            web.loadDataWithBaseURL(null, html, "text/html", "utf-8", null);
        }
    }

    private String hostOf(String url) {
        try {
            String h = android.net.Uri.parse(url).getHost();
            return h == null ? "" : h;
        } catch (Exception e) {
            return "";
        }
    }

    private void showBar() {
        if (bar == null) return;
        bar.setVisibility(View.VISIBLE);
        bar.bringToFront();
        handler.removeCallbacks(hideBar);
        handler.postDelayed(hideBar, 3500);
    }

    private int dp(int v) {
        return (int) (v * getResources().getDisplayMetrics().density + 0.5f);
    }

    @SuppressWarnings("deprecation")
    private void hideSystemUi() {
        getWindow().getDecorView().setSystemUiVisibility(
                View.SYSTEM_UI_FLAG_LAYOUT_STABLE
                        | View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION
                        | View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN
                        | View.SYSTEM_UI_FLAG_HIDE_NAVIGATION
                        | View.SYSTEM_UI_FLAG_FULLSCREEN
                        | View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY);
    }

    @Override
    public void onWindowFocusChanged(boolean hasFocus) {
        super.onWindowFocusChanged(hasFocus);
        if (hasFocus) hideSystemUi();
    }

    @Override
    @SuppressWarnings("deprecation")
    public void onBackPressed() {
        if (customView != null) {
            // Thoát chế độ toàn màn hình của video, giữ lại màn hình phát
            if (chrome != null) {
                chrome.onHideCustomView();
            }
            return;
        }
        super.onBackPressed();
    }

    @Override
    protected void onPause() {
        if (web != null) web.onPause();
        super.onPause();
    }

    @Override
    protected void onResume() {
        super.onResume();
        if (web != null) web.onResume();
    }

    @Override
    protected void onDestroy() {
        handler.removeCallbacks(hideBar);
        if (web != null) {
            web.loadUrl("about:blank");
            web.stopLoading();
            root.removeView(web);
            web.destroy();
            web = null;
        }
        super.onDestroy();
    }
}
