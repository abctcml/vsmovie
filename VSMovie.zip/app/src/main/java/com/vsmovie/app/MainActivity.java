package com.vsmovie.app;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.os.Build;
import android.os.Bundle;
import android.view.ViewGroup;
import android.webkit.JavascriptInterface;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceRequest;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.FrameLayout;
import android.widget.Toast;

import org.json.JSONObject;

import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.nio.charset.StandardCharsets;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

/**
 * Màn hình chính: một WebView hiển thị giao diện (assets/www) và một "cầu nối" JS <-> Java.
 * - Android.request(id, url): gọi API bằng Java (không bị CORS) rồi trả kết quả về JS.
 * - Android.play(json): mở trình phát toàn màn hình.
 * - Android.storeGet/storeSet: lưu dữ liệu (danh sách của tôi, lịch sử...) bằng SharedPreferences.
 */
public class MainActivity extends Activity {

    private static MainActivity current;

    private WebView webView;
    private final ExecutorService pool = Executors.newFixedThreadPool(4);

    @SuppressLint({"SetJavaScriptEnabled", "AddJavascriptInterface"})
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        current = this;

        FrameLayout root = new FrameLayout(this);
        root.setBackgroundColor(Color.BLACK);

        webView = new WebView(this);
        webView.setBackgroundColor(Color.BLACK);
        root.addView(webView, new FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));
        setContentView(root);

        WebSettings s = webView.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setAllowFileAccess(true);
        s.setMediaPlaybackRequiresUserGesture(false);
        s.setSupportZoom(false);
        s.setBuiltInZoomControls(false);
        s.setTextZoom(100);
        s.setMixedContentMode(WebSettings.MIXED_CONTENT_ALWAYS_ALLOW);

        webView.setOverScrollMode(WebView.OVER_SCROLL_NEVER);
        webView.setWebChromeClient(new WebChromeClient());
        webView.setWebViewClient(new WebViewClient() {
            @Override
            public boolean shouldOverrideUrlLoading(WebView view, WebResourceRequest request) {
                String u = request.getUrl().toString();
                // Chỉ cho phép trang nội bộ. Link ngoài sẽ bị chặn.
                return !u.startsWith("file:///android_asset/");
            }
        });
        webView.addJavascriptInterface(new Bridge(), "Android");
        webView.loadUrl("file:///android_asset/www/index.html");
    }

    /** Gọi từ PlayerActivity khi người dùng đổi tập. */
    static void notifyEpisode(final int index) {
        final MainActivity a = current;
        if (a == null || a.webView == null) return;
        a.runOnUiThread(new Runnable() {
            @Override
            public void run() {
                a.webView.evaluateJavascript(
                        "window.__onEpisode && window.__onEpisode(" + index + ")", null);
            }
        });
    }

    @Override
    @SuppressWarnings("deprecation")
    public void onBackPressed() {
        if (webView == null) {
            super.onBackPressed();
            return;
        }
        webView.evaluateJavascript(
                "(window.__onBack ? window.__onBack() : false)",
                new android.webkit.ValueCallback<String>() {
                    @Override
                    public void onReceiveValue(String value) {
                        if (!"true".equals(value)) {
                            finish();
                        }
                    }
                });
    }

    @Override
    protected void onResume() {
        super.onResume();
        if (webView != null) webView.onResume();
    }

    @Override
    protected void onPause() {
        if (webView != null) webView.onPause();
        super.onPause();
    }

    @Override
    protected void onDestroy() {
        if (current == this) current = null;
        pool.shutdownNow();
        if (webView != null) {
            webView.removeJavascriptInterface("Android");
            webView.destroy();
            webView = null;
        }
        super.onDestroy();
    }

    /** Các hàm JS có thể gọi. Chạy trên thread riêng của WebView, KHÔNG phải UI thread. */
    private class Bridge {

        @JavascriptInterface
        public void request(final String id, final String url) {
            pool.execute(new Runnable() {
                @Override
                public void run() {
                    int code = 0;
                    String body = "";
                    HttpURLConnection c = null;
                    try {
                        c = (HttpURLConnection) new URL(url).openConnection();
                        c.setConnectTimeout(15000);
                        c.setReadTimeout(25000);
                        c.setInstanceFollowRedirects(true);
                        c.setRequestProperty("User-Agent",
                                "Mozilla/5.0 (Linux; Android 13; Mobile) AppleWebKit/537.36 "
                                        + "(KHTML, like Gecko) Chrome/120.0 Mobile Safari/537.36");
                        c.setRequestProperty("Accept", "application/json, text/plain, */*");
                        c.setRequestProperty("Referer", "https://vsmov.com/");
                        code = c.getResponseCode();
                        InputStream in = code >= 400 ? c.getErrorStream() : c.getInputStream();
                        if (in != null) {
                            ByteArrayOutputStream out = new ByteArrayOutputStream();
                            byte[] buf = new byte[8192];
                            int n;
                            while ((n = in.read(buf)) > 0) out.write(buf, 0, n);
                            in.close();
                            body = new String(out.toByteArray(), StandardCharsets.UTF_8);
                        }
                    } catch (Exception e) {
                        code = 0;
                        body = String.valueOf(e.getMessage());
                    } finally {
                        if (c != null) c.disconnect();
                    }
                    final String js = "window.__nativeCb(" + JSONObject.quote(id) + ","
                            + code + "," + JSONObject.quote(body) + ")";
                    runOnUiThread(new Runnable() {
                        @Override
                        public void run() {
                            if (webView != null) webView.evaluateJavascript(js, null);
                        }
                    });
                }
            });
        }

        @JavascriptInterface
        public void play(final String json) {
            runOnUiThread(new Runnable() {
                @Override
                public void run() {
                    Intent i = new Intent(MainActivity.this, PlayerActivity.class);
                    i.putExtra("payload", json);
                    startActivity(i);
                }
            });
        }

        @JavascriptInterface
        public void share(final String text) {
            runOnUiThread(new Runnable() {
                @Override
                public void run() {
                    Intent i = new Intent(Intent.ACTION_SEND);
                    i.setType("text/plain");
                    i.putExtra(Intent.EXTRA_TEXT, text);
                    startActivity(Intent.createChooser(i, "Chia sẻ"));
                }
            });
        }

        @JavascriptInterface
        public void toast(final String msg) {
            runOnUiThread(new Runnable() {
                @Override
                public void run() {
                    Toast.makeText(MainActivity.this, msg, Toast.LENGTH_SHORT).show();
                }
            });
        }

        @JavascriptInterface
        public String storeGet(String key) {
            SharedPreferences sp = getSharedPreferences("vsmovie", MODE_PRIVATE);
            return sp.getString(key, null);
        }

        @JavascriptInterface
        public void storeSet(String key, String value) {
            SharedPreferences sp = getSharedPreferences("vsmovie", MODE_PRIVATE);
            sp.edit().putString(key, value).apply();
        }

        @JavascriptInterface
        public String version() {
            return "1.0 (sdk " + Build.VERSION.SDK_INT + ")";
        }
    }
}
