(function () {
'use strict';

/* =====================================================================
   VSMovie - giao diện kiểu Netflix, nguồn phim: API của vsmov.com
   ===================================================================== */

var ORIGIN = 'https://vsmov.com';
var DEFAULT_BASE = ORIGIN + '/api';

/* ---------------------------------------------------------------- helpers */
function $(s, r) { return (r || document).querySelector(s); }
function $$(s, r) { return Array.prototype.slice.call((r || document).querySelectorAll(s)); }
function esc(s) {
  return String(s == null ? '' : s).replace(/[&<>"']/g, function (c) {
    return { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c];
  });
}
function sleep(ms) { return new Promise(function (r) { setTimeout(r, ms); }); }
function hasNative() { return !!(window.Android && window.Android.request); }

var IC = {
  home: 'M12 3l9 8h-3v9h-5v-6h-2v6H6v-9H3z',
  hot: 'M4 5h16a1 1 0 0 1 1 1v12a1 1 0 0 1-1 1H4a1 1 0 0 1-1-1V6a1 1 0 0 1 1-1zm6 3.5v7l6-3.5z',
  search: 'M15.5 14h-.8l-.3-.3A6.5 6.5 0 1 0 14 15.5l.3.3v.8l5 5 1.5-1.5-5-5zm-6 0a4.5 4.5 0 1 1 0-9 4.5 4.5 0 0 1 0 9z',
  user: 'M12 12a4.5 4.5 0 1 0 0-9 4.5 4.5 0 0 0 0 9zm0 2c-3.3 0-9 1.7-9 5v2h18v-2c0-3.3-5.7-5-9-5z',
  play: 'M8 5v14l11-7z',
  plus: 'M19 13h-6v6h-2v-6H5v-2h6V5h2v6h6z',
  check: 'M9 16.2L4.8 12l-1.4 1.4L9 19 21 7l-1.4-1.4z',
  info: 'M11 7h2v2h-2zm0 4h2v6h-2zm1-9a10 10 0 1 0 0 20 10 10 0 0 0 0-20zm0 18a8 8 0 1 1 0-16 8 8 0 0 1 0 16z',
  back: 'M20 11H7.8l5.6-5.6L12 4l-8 8 8 8 1.4-1.4L7.8 13H20z',
  like: 'M1 21h4V9H1v12zm22-11c0-1.1-.9-2-2-2h-6.3l1-4.6v-.3c0-.4-.2-.8-.4-1.1L14.2 1 7.6 7.6C7.2 8 7 8.5 7 9v10c0 1.1.9 2 2 2h9c.8 0 1.5-.5 1.8-1.2l3-7c.1-.2.2-.5.2-.8v-2z',
  share: 'M18 16.1c-.8 0-1.5.3-2 .8l-7.1-4.2c.1-.2.1-.5.1-.7s0-.5-.1-.7L16 7.2c.5.5 1.2.8 2 .8 1.7 0 3-1.3 3-3s-1.3-3-3-3-3 1.3-3 3c0 .2 0 .5.1.7L8 9.8C7.5 9.3 6.8 9 6 9c-1.7 0-3 1.3-3 3s1.3 3 3 3c.8 0 1.5-.3 2-.8l7.2 4.2c-.1.2-.1.4-.1.6 0 1.6 1.3 2.9 2.9 2.9s2.9-1.3 2.9-2.9-1.2-2.9-2.9-2.9z',
  close: 'M19 6.4L17.6 5 12 10.6 6.4 5 5 6.4 10.6 12 5 17.6 6.4 19 12 13.4 17.6 19 19 17.6 13.4 12z',
  chev: 'M9 6l6 6-6 6-1.4-1.4L12.2 12 7.6 7.4z',
  list: 'M3 13h2v-2H3v2zm0 4h2v-2H3v2zm0-8h2V7H3v2zm4 4h14v-2H7v2zm0 4h14v-2H7v2zM7 7v2h14V7H7z',
  trash: 'M6 19c0 1.1.9 2 2 2h8c1.1 0 2-.9 2-2V7H6v12zM19 4h-3.5l-1-1h-5l-1 1H5v2h14V4z',
  swap: 'M16 17.01V10h-2v7.01h-3L15 21l4-3.99h-3zM9 3L5 6.99h3V14h2V6.99h3L9 3z',
  gear: 'M19.4 13a7.5 7.5 0 0 0 0-2l2.1-1.6-2-3.5-2.5 1a7.4 7.4 0 0 0-1.7-1L15 3.3h-4l-.4 2.6a7.4 7.4 0 0 0-1.7 1l-2.5-1-2 3.5L6.6 11a7.5 7.5 0 0 0 0 2l-2.1 1.6 2 3.5 2.5-1c.5.4 1.1.7 1.7 1l.4 2.6h4l.4-2.6c.6-.3 1.2-.6 1.7-1l2.5 1 2-3.5L19.4 13zM12 15.5a3.5 3.5 0 1 1 0-7 3.5 3.5 0 0 1 0 7z'
};
function ic(name, size) {
  size = size || 24;
  return '<svg class="ic" width="' + size + '" height="' + size + '" viewBox="0 0 24 24" fill="currentColor" fill-rule="evenodd"><path d="' + IC[name] + '"/></svg>';
}

/* ---------------------------------------------------------------- storage */
var Store = {
  get: function (k, d) {
    try {
      var v = (window.Android && window.Android.storeGet) ? window.Android.storeGet(k) : localStorage.getItem(k);
      if (v === null || v === undefined || v === '') return d;
      return JSON.parse(v);
    } catch (e) { return d; }
  },
  set: function (k, v) {
    try {
      var s = JSON.stringify(v);
      if (window.Android && window.Android.storeSet) window.Android.storeSet(k, s);
      else localStorage.setItem(k, s);
    } catch (e) { /* ignore */ }
  }
};

/* ---------------------------------------------------------------- toast / dialog / sheet */
var toastTimer = null;
function toast(msg) {
  var t = $('#toast');
  t.textContent = msg;
  t.classList.add('show');
  clearTimeout(toastTimer);
  toastTimer = setTimeout(function () { t.classList.remove('show'); }, 2200);
}

var dialogResolve = null;
function ask(o) {
  // o: {title, text, input, value, ok, cancel}
  return new Promise(function (resolve) {
    var d = $('#dialog');
    d.innerHTML = '<div class="dlg"><h3>' + esc(o.title || '') + '</h3>' +
      (o.text ? '<p>' + esc(o.text) + '</p>' : '') +
      (o.input ? '<input id="dlg-in" type="text" value="' + esc(o.value || '') + '">' : '') +
      '<div class="bt">' + (o.cancel === false ? '' : '<button data-act="dlg-no">' + esc(o.cancel || 'Hủy') + '</button>') +
      '<button class="pri" data-act="dlg-ok">' + esc(o.ok || 'OK') + '</button></div></div>';
    d.classList.remove('hidden');
    dialogResolve = function (ok) {
      var val = o.input ? ($('#dlg-in') ? $('#dlg-in').value : '') : ok;
      d.classList.add('hidden');
      d.innerHTML = '';
      dialogResolve = null;
      resolve(ok ? (o.input ? val : true) : (o.input ? null : false));
    };
    if (o.input) setTimeout(function () { var i = $('#dlg-in'); if (i) i.focus(); }, 60);
  });
}

var sheetOpen = false;
function openSheet(title, html) {
  var s = $('#sheet');
  s.innerHTML = '<div class="sheet-in"><h3>' + esc(title) + '</h3>' + html + '</div>';
  s.classList.remove('hidden');
  sheetOpen = true;
}
function closeSheet() {
  var s = $('#sheet');
  s.classList.add('hidden');
  s.innerHTML = '';
  sheetOpen = false;
}

/* ---------------------------------------------------------------- HTTP (qua Java để không bị CORS) */
var seq = 0;
var pending = {};
window.__nativeCb = function (id, code, body) {
  var p = pending[id];
  if (!p) return;
  delete pending[id];
  p.res({ code: code, body: body });
};
function rawGet(url) {
  return new Promise(function (res, rej) {
    if (hasNative()) {
      var id = 'r' + (++seq);
      pending[id] = { res: res, rej: rej };
      try { window.Android.request(id, url); } catch (e) { delete pending[id]; rej(e); return; }
      setTimeout(function () {
        if (pending[id]) { delete pending[id]; rej(new Error('Hết thời gian chờ máy chủ')); }
      }, 40000);
    } else {
      fetch(url).then(function (r) {
        return r.text().then(function (t) { res({ code: r.status, body: t }); });
      }).catch(function (e) { rej(new Error(e && e.message ? e.message : 'Lỗi mạng')); });
    }
  });
}

var cache = {};
function getJSON(url, ttl) {
  ttl = ttl == null ? 300000 : ttl;
  var c = cache[url];
  if (c && Date.now() - c.t < ttl) return c.p;
  var p = rawGet(url).then(function (o) {
    if (o.code === 0) throw new Error('Không kết nối được: ' + String(o.body).slice(0, 100));
    if (o.code < 200 || o.code >= 300) throw new Error('Máy chủ trả lỗi HTTP ' + o.code);
    try { return JSON.parse(o.body); }
    catch (e) { throw new Error('Phản hồi không phải JSON: ' + String(o.body).slice(0, 80)); }
  });
  cache[url] = { t: Date.now(), p: p };
  p.catch(function () { delete cache[url]; });
  return p;
}

function apiBase() {
  var b = Store.get('apiBase', DEFAULT_BASE);
  return String(b || DEFAULT_BASE).replace(/\/+$/, '');
}
function originOf(base) {
  var m = String(base).match(/^(https?:\/\/[^\/]+)/i);
  return m ? m[1] : ORIGIN;
}

/* ---------------------------------------------------------------- chuẩn hoá dữ liệu */
var cdnImg = '';
function noteCdn(j) {
  var d = (j && j.data && typeof j.data === 'object') ? j.data : j;
  var c = d && (d.APP_DOMAIN_CDN_IMAGE || d.cdn_image || d.domain_cdn_image);
  if (c && typeof c === 'string') cdnImg = c.replace(/\/+$/, '');
}
function imgUrl(u) {
  if (!u) return '';
  u = String(u);
  if (/^https?:\/\//i.test(u)) return u;
  if (u.indexOf('//') === 0) return 'https:' + u;
  var o = originOf(apiBase());
  if (u.charAt(0) === '/') return o + u;
  if (/^storage\//.test(u)) return o + '/' + u;
  return (cdnImg || (o + '/storage/images')) + '/' + u;
}
function stripHtml(s) {
  if (!s) return '';
  try {
    var d = new DOMParser().parseFromString(String(s), 'text/html');
    return (d.body.textContent || '').replace(/\s+/g, ' ').trim();
  } catch (e) { return String(s).replace(/<[^>]*>/g, ' ').trim(); }
}
function normMovie(m) {
  m = m || {};
  return {
    slug: m.slug || '',
    name: m.name || m.title || '',
    origin: m.origin_name || m.original_name || '',
    thumb: imgUrl(m.thumb_url || m.thumb),
    poster: imgUrl(m.poster_url || m.poster),
    year: m.year || '',
    quality: m.quality || '',
    lang: m.lang || '',
    ep: m.episode_current || '',
    time: m.time || '',
    type: m.type || ''
  };
}
function pickList(j) {
  if (!j) return { items: [], pg: {} };
  noteCdn(j);
  if (Array.isArray(j)) return { items: j, pg: {} };
  var d = (j.data && typeof j.data === 'object') ? j.data : j;
  var items = Array.isArray(d) ? d : (d.items || d.movies || d.list || d.results || j.items || []);
  if (!Array.isArray(items)) items = [];
  var pg = d.pagination || (d.params && d.params.pagination) || j.pagination || {};
  return { items: items, pg: pg };
}
function totalPages(pg) {
  return Number(pg.totalPages || pg.total_pages || pg.last_page || pg.lastPage || 0) || 0;
}

var PATTERNS = {
  list: [function (k, p) { return '/danh-sach/' + k + '?page=' + p + '&limit=24'; }],
  genre: [
    function (k, p) { return '/the-loai/' + k + '?page=' + p + '&limit=24'; },
    function (k, p) { return '/danh-sach?category=' + k + '&page=' + p + '&limit=24'; }
  ],
  country: [
    function (k, p) { return '/quoc-gia/' + k + '?page=' + p + '&limit=24'; },
    function (k, p) { return '/danh-sach?country=' + k + '&page=' + p + '&limit=24'; }
  ],
  year: [
    function (k, p) { return '/nam-phat-hanh/' + k + '?page=' + p + '&limit=24'; },
    function (k, p) { return '/danh-sach?year=' + k + '&page=' + p + '&limit=24'; }
  ],
  search: [function (k, p) { return '/tim-kiem?keyword=' + encodeURIComponent(k) + '&page=' + p + '&limit=24'; }]
};
var goodPattern = {};
var known = {}; // slug -> movie đã biết (để vẽ nhanh trang chi tiết)

function fetchList(kind, key, page) {
  var pats = PATTERNS[kind] || PATTERNS.list;
  var order = [];
  var i;
  for (i = 0; i < pats.length; i++) order.push(i);
  if (goodPattern[kind] != null) {
    order = [goodPattern[kind]].concat(order.filter(function (x) { return x !== goodPattern[kind]; }));
  }
  var lastErr = null, gotValid = false;
  var chain = Promise.resolve(null);
  order.forEach(function (pi) {
    chain = chain.then(function (found) {
      if (found) return found;
      return getJSON(apiBase() + pats[pi](key, page)).then(function (j) {
        var r = pickList(j);
        gotValid = true;
        if (r.items.length) {
          goodPattern[kind] = pi;
          var items = r.items.map(normMovie).filter(function (m) { return m.slug; });
          items.forEach(function (m) { known[m.slug] = m; });
          return { items: items, pg: r.pg };
        }
        return null;
      }, function (e) { lastErr = e; return null; });
    });
  });
  return chain.then(function (found) {
    if (found) return found;
    if (!gotValid && lastErr) throw lastErr;
    return { items: [], pg: {} };
  });
}

function fetchMovie(slug) {
  return getJSON(apiBase() + '/phim/' + encodeURIComponent(slug), 120000).then(function (j) {
    noteCdn(j);
    var d = (j && j.data && typeof j.data === 'object' && (j.data.movie || j.data.item)) ? j.data : j;
    var m = (d && (d.movie || d.item)) || d || {};
    var eps = (d && d.episodes) || m.episodes || [];
    var servers = [];
    (Array.isArray(eps) ? eps : []).forEach(function (s) {
      var list = (s.server_data || s.items || []).map(function (e) {
        return { name: String(e.name == null ? '' : e.name), slug: e.slug || '', embed: e.link_embed || '', m3u8: e.link_m3u8 || '' };
      });
      if (list.length) servers.push({ name: s.server_name || 'Server', list: list });
    });
    var mv = normMovie(m);
    mv.content = stripHtml(m.content);
    mv.category = Array.isArray(m.category) ? m.category : [];
    mv.country = Array.isArray(m.country) ? m.country : [];
    mv.actor = Array.isArray(m.actor) ? m.actor : [];
    mv.director = Array.isArray(m.director) ? m.director : [];
    mv.total = m.episode_total || '';
    if (!mv.slug) mv.slug = slug;
    known[mv.slug] = Object.assign({}, known[mv.slug] || {}, mv);
    return { movie: mv, servers: servers };
  });
}

var FALLBACK_GENRES = [
  ['Hành Động', 'hanh-dong'], ['Tình Cảm', 'tinh-cam'], ['Hài Hước', 'hai-huoc'], ['Cổ Trang', 'co-trang'],
  ['Tâm Lý', 'tam-ly'], ['Hình Sự', 'hinh-su'], ['Kinh Dị', 'kinh-di'], ['Viễn Tưởng', 'vien-tuong'],
  ['Phiêu Lưu', 'phieu-luu'], ['Chính Kịch', 'chinh-kich'], ['Bí Ẩn', 'bi-an'], ['Hoạt Hình', 'hoat-hinh'],
  ['Gia Đình', 'gia-dinh'], ['Võ Thuật', 'vo-thuat'], ['Thần Thoại', 'than-thoai'], ['Chiến Tranh', 'chien-tranh']
].map(function (a) { return { name: a[0], slug: a[1] }; });
var FALLBACK_COUNTRIES = [
  ['Hàn Quốc', 'han-quoc'], ['Trung Quốc', 'trung-quoc'], ['Âu Mỹ', 'au-my'], ['Nhật Bản', 'nhat-ban'],
  ['Thái Lan', 'thai-lan'], ['Việt Nam', 'viet-nam'], ['Đài Loan', 'dai-loan'], ['Hồng Kông', 'hong-kong'],
  ['Ấn Độ', 'an-do'], ['Anh', 'anh'], ['Pháp', 'phap'], ['Canada', 'canada']
].map(function (a) { return { name: a[0], slug: a[1] }; });

function fetchTaxonomy(path, fallback) {
  return getJSON(apiBase() + path, 3600000).then(function (j) {
    var r = pickList(j);
    var items = r.items.map(function (x) { return { name: x.name || x.title || '', slug: x.slug || '' }; })
      .filter(function (x) { return x.name && x.slug; });
    return items.length ? items : fallback;
  }, function () { return fallback; });
}

/* ---------------------------------------------------------------- hồ sơ & dữ liệu cá nhân */
var COLORS = ['#e50914', '#1e88e5', '#43a047', '#fb8c00', '#8e24aa'];
var FACES = ['😀', '😎', '🤖', '🦊', '🐼'];
var profiles = Store.get('profiles', null);
if (!profiles || !profiles.length) {
  profiles = [{ id: 'p1', name: 'Hồ sơ 1', c: 0 }];
  Store.set('profiles', profiles);
}
var me = null;
function pk(k) { return 'p:' + me.id + ':' + k; }
function mini(m) {
  return { slug: m.slug, name: m.name, origin: m.origin, thumb: m.thumb, poster: m.poster, year: m.year, quality: m.quality, ep: m.ep, type: m.type };
}
function getList() { return Store.get(pk('list'), []); }
function inList(slug) { return getList().some(function (x) { return x.slug === slug; }); }
function toggleList(m) {
  var l = getList();
  var i = -1;
  l.forEach(function (x, idx) { if (x.slug === m.slug) i = idx; });
  if (i >= 0) { l.splice(i, 1); Store.set(pk('list'), l); toast('Đã xóa khỏi Danh sách của tôi'); }
  else { l.unshift(mini(m)); Store.set(pk('list'), l); toast('Đã thêm vào Danh sách của tôi'); }
  return i < 0;
}
function getLikes() { return Store.get(pk('likes'), []); }
function isLiked(slug) { return getLikes().indexOf(slug) >= 0; }
function toggleLike(slug) {
  var l = getLikes();
  var i = l.indexOf(slug);
  if (i >= 0) l.splice(i, 1); else l.push(slug);
  Store.set(pk('likes'), l);
  return i < 0;
}
function getHist() { return Store.get(pk('hist'), {}); }
function histArr() {
  var h = getHist();
  return Object.keys(h).map(function (k) { return h[k]; }).sort(function (a, b) { return b.ts - a.ts; });
}
function saveHist(m, si, ei, epName, total) {
  var h = getHist();
  h[m.slug] = { m: mini(m), si: si, ei: ei, epName: epName, total: total || 0, ts: Date.now() };
  var keys = Object.keys(h);
  if (keys.length > 60) {
    keys.sort(function (a, b) { return h[a].ts - h[b].ts; });
    delete h[keys[0]];
  }
  Store.set(pk('hist'), h);
}
function getRecent() { return Store.get(pk('recent'), []); }
function addRecent(q) {
  var r = getRecent().filter(function (x) { return x !== q; });
  r.unshift(q);
  Store.set(pk('recent'), r.slice(0, 8));
}

/* ---------------------------------------------------------------- hình ảnh: tự đổi poster/thumb nếu sai chiều */
document.addEventListener('load', function (e) {
  var t = e.target;
  if (!t || t.tagName !== 'IMG') return;
  var want = t.getAttribute('data-want');
  var alt = t.getAttribute('data-alt');
  if (alt && !t.getAttribute('data-tried') && t.naturalWidth && t.naturalHeight) {
    var land = t.naturalWidth >= t.naturalHeight;
    if ((want === 'l' && !land) || (want === 'p' && land)) {
      t.setAttribute('data-tried', '1');
      t.src = alt;
      return;
    }
  }
  t.classList.add('ld');
}, true);
document.addEventListener('error', function (e) {
  var t = e.target;
  if (!t || t.tagName !== 'IMG') return;
  var alt = t.getAttribute('data-alt');
  if (alt && !t.getAttribute('data-tried')) { t.setAttribute('data-tried', '1'); t.src = alt; }
  else t.classList.add('bad');
}, true);

function pic(src, alt, want, extra) {
  if (!src && alt) { src = alt; alt = ''; }
  return '<img ' + (extra || '') + ' loading="lazy" decoding="async" data-want="' + want + '"' +
    (alt && alt !== src ? ' data-alt="' + esc(alt) + '"' : '') + ' src="' + esc(src) + '" alt="">';
}

/* ---------------------------------------------------------------- vẽ thẻ phim */
function cardHTML(m, o) {
  o = o || {};
  var badge = o.badge != null ? o.badge : (m.ep || m.quality || '');
  return '<a class="card' + (o.wide ? ' wide' : '') + '" data-act="open" data-slug="' + esc(m.slug) + '">' +
    pic(o.wide ? (m.poster || m.thumb) : (m.thumb || m.poster), o.wide ? m.thumb : m.poster, o.wide ? 'l' : 'p') +
    '<div class="noimg">' + esc(m.name) + '</div>' +
    (badge ? '<span class="bdg">' + esc(badge) + '</span>' : '') +
    (o.cap ? '<div class="cap">' + esc(m.name) + '</div>' : '') +
    (o.prog != null ? '<div class="prog"><b style="width:' + Math.round(o.prog * 100) + '%"></b></div>' : '') +
    '</a>';
}
function rowHTML(id, title, itemsHTML, more) {
  return '<div class="row" id="row-' + id + '"><div class="row-h"><h2>' + esc(title) + '</h2>' +
    (more ? '<a data-act="more" data-kind="' + more.kind + '" data-key="' + esc(more.key) + '" data-title="' + esc(title) + '">Xem tất cả ' + ic('chev', 16) + '</a>' : '') +
    '</div><div class="scroller">' + itemsHTML + '</div></div>';
}
function skelRow(id) {
  var s = '';
  for (var i = 0; i < 5; i++) s += '<div class="card sk"></div>';
  return '<div class="row" id="row-' + id + '"><div class="row-h"><div class="sk-box sk-title"></div></div><div class="scroller">' + s + '</div></div>';
}
function errHTML(e) {
  return '<div class="err"><div class="err-t">Không tải được dữ liệu</div><div class="err-m">' + esc(e && e.message ? e.message : e) +
    '</div><button class="btn white" data-act="reload">Thử lại</button><button class="btn grey" data-act="api-setting">Đổi địa chỉ API</button></div>';
}
function loaderHTML() { return '<div class="loader"><div class="spin"></div></div>'; }

/* ---------------------------------------------------------------- điều hướng */
var curTab = 'home';
var stack = []; // các trang phủ lên trên
var tabInit = {};

function renderTabbar() {
  var items = [['home', 'Trang chủ'], ['hot', 'Mới & Hot'], ['search', 'Tìm kiếm'], ['mine', 'Của tôi']];
  var icons = { home: 'home', hot: 'hot', search: 'search', mine: 'user' };
  $('#tabbar').innerHTML = items.map(function (it) {
    return '<button data-act="tab" data-tab="' + it[0] + '" class="' + (curTab === it[0] ? 'on' : '') + '">' + ic(icons[it[0]], 24) + '<span>' + it[1] + '</span></button>';
  }).join('');
}
function switchTab(t) {
  while (stack.length) popPage(true);
  curTab = t;
  $$('.tab').forEach(function (el) { el.classList.toggle('on', el.id === 'tab-' + t); });
  renderTabbar();
  if (t === 'home') refreshLocalRows();
  if (t === 'hot' && !tabInit.hot) { tabInit.hot = true; initHot(); }
  if (t === 'search') { if (!tabInit.search) { tabInit.search = true; initSearch(); } else renderSearchIdle(); }
  if (t === 'mine') renderMine();
}
function pushPage(cls) {
  var p = document.createElement('div');
  p.className = 'page ' + (cls || '');
  $('#overlays').appendChild(p);
  stack.push(p);
  return p;
}
function popPage(silent) {
  var p = stack.pop();
  if (p && p.parentNode) p.parentNode.removeChild(p);
  if (!silent && stack.length === 0 && curTab === 'home') refreshLocalRows();
  if (!silent && stack.length === 0 && curTab === 'mine') renderMine();
}
window.__onBack = function () {
  if (dialogResolve) { dialogResolve(false); return true; }
  if (sheetOpen) { closeSheet(); return true; }
  if (stack.length) { popPage(); return true; }
  if (curTab !== 'home') { switchTab('home'); return true; }
  return false;
};

/* ---------------------------------------------------------------- Trang chủ */
var HOME_ROWS = [
  { id: 'new', title: 'Mới cập nhật', kind: 'list', key: 'phim-moi-cap-nhat' },
  { id: 'top', title: 'Top 10 hôm nay', top: true },
  { id: 'bo', title: 'Phim bộ hay', kind: 'list', key: 'phim-bo' },
  { id: 'le', title: 'Phim lẻ đặc sắc', kind: 'list', key: 'phim-le' },
  { id: 'sub', title: 'Vietsub độc quyền', kind: 'list', key: 'subteam' },
  { id: 'kr', title: 'Phim Hàn Quốc', kind: 'country', key: 'han-quoc' },
  { id: 'cn', title: 'Phim Trung Quốc', kind: 'country', key: 'trung-quoc' },
  { id: 'us', title: 'Phim Âu Mỹ', kind: 'country', key: 'au-my' },
  { id: 'hh', title: 'Hoạt hình', kind: 'list', key: 'hoat-hinh' },
  { id: 'jp', title: 'Phim Nhật Bản', kind: 'country', key: 'nhat-ban' },
  { id: 'th', title: 'Phim Thái Lan', kind: 'country', key: 'thai-lan' },
  { id: 'tv', title: 'TV Shows', kind: 'list', key: 'tv-shows' }
];
var heroMovie = null;

function renderHome() {
  var el = $('#tab-home');
  el.innerHTML =
    '<div class="hbar"><div class="hbar-top"><div class="logo">VSMOVIE</div><div class="hbar-r">' +
    '<button data-act="tab" data-tab="search">' + ic('search', 26) + '</button>' +
    '<button class="mini-av" data-act="profiles" style="background:' + COLORS[me.c % COLORS.length] + '">' + FACES[me.c % FACES.length] + '</button>' +
    '</div></div><div class="chips">' +
    '<button class="chip" data-act="more" data-kind="list" data-key="phim-bo" data-title="Phim bộ">Phim bộ</button>' +
    '<button class="chip" data-act="more" data-kind="list" data-key="phim-le" data-title="Phim lẻ">Phim lẻ</button>' +
    '<button class="chip" data-act="more" data-kind="list" data-key="hoat-hinh" data-title="Hoạt hình">Hoạt hình</button>' +
    '<button class="chip" data-act="genres">Thể loại ▾</button>' +
    '<button class="chip" data-act="countries">Quốc gia ▾</button></div></div>' +
    '<div id="hero" class="hero"><div class="sk-box" style="position:absolute;inset:0"></div></div>' +
    '<div class="rows"><div id="local-rows"></div><div id="remote-rows">' +
    HOME_ROWS.map(function (r) { return '<div id="slot-' + r.id + '"></div>'; }).join('') + '</div></div>';
  refreshLocalRows();
  loadHome();
}

function refreshLocalRows() {
  var box = $('#local-rows');
  if (!box || !me) return;
  var html = '';
  var h = histArr();
  if (h.length) {
    html += rowHTML('cont', 'Tiếp tục xem cho ' + me.name, h.slice(0, 15).map(function (x) {
      var p = x.total > 1 ? Math.min(1, (x.ei + 1) / x.total) : 0.5;
      return cardHTML(x.m, { badge: x.epName || '', prog: p });
    }).join(''), null);
  }
  var l = getList();
  if (l.length) {
    html += rowHTML('mylist', 'Danh sách của tôi', l.slice(0, 20).map(function (m) { return cardHTML(m); }).join(''), { kind: 'mylist', key: 'x' });
  }
  box.innerHTML = html;
}

function setHero(m) {
  heroMovie = m;
  var el = $('#hero');
  if (!el) return;
  var sub = [];
  if (m.year) sub.push(m.year);
  if (m.quality) sub.push(m.quality);
  if (m.lang) sub.push(m.lang);
  if (m.ep) sub.push(m.ep);
  el.innerHTML = pic(m.poster || m.thumb, m.thumb, 'l') +
    '<div class="hero-info" data-act="open" data-slug="' + esc(m.slug) + '"><div class="hero-title">' + esc(m.name) + '</div>' +
    '<div class="hero-sub">' + sub.map(esc).join('<i>•</i>') + '</div>' +
    '<div class="hero-btns"><button class="btn white" data-act="quickplay" data-slug="' + esc(m.slug) + '">' + ic('play', 22) + 'Phát</button>' +
    '<button class="btn grey" data-act="heroadd">' + ic(inList(m.slug) ? 'check' : 'plus', 22) + 'Danh sách</button></div></div>';
}

function pool(tasks, n) {
  var i = 0;
  function worker() {
    if (i >= tasks.length) return Promise.resolve();
    var t = tasks[i++];
    return Promise.resolve().then(t).catch(function () { }).then(worker);
  }
  var ws = [];
  for (var k = 0; k < n; k++) ws.push(worker());
  return Promise.all(ws);
}

function loadHome() {
  var firstErr = null;
  var newItems = null;
  var tasks = HOME_ROWS.map(function (r) {
    return function () {
      var slot = $('#slot-' + r.id);
      if (!slot) return null;
      if (r.top) return null; // vẽ sau khi có dữ liệu "mới cập nhật"
      slot.innerHTML = skelRow(r.id);
      return fetchList(r.kind, r.key, 1).then(function (res) {
        var s = $('#slot-' + r.id);
        if (!s) return;
        if (!res.items.length) { s.innerHTML = ''; return; }
        s.innerHTML = rowHTML(r.id, r.title, res.items.map(function (m) { return cardHTML(m); }).join(''), { kind: r.kind, key: r.key });
        if (r.id === 'new') {
          newItems = res.items;
          var cand = res.items.filter(function (m) { return m.poster || m.thumb; }).slice(0, 8);
          if (cand.length) setHero(cand[Math.floor(Math.random() * cand.length)]);
          var ts = $('#slot-top');
          if (ts) {
            ts.innerHTML = rowHTML('top', 'Top 10 hôm nay', res.items.slice(0, 10).map(function (m, i) {
              return '<div class="top-item"><div class="num">' + (i + 1) + '</div>' + cardHTML(m, { badge: '' }) + '</div>';
            }).join(''), null);
          }
        }
      }, function (e) {
        if (!firstErr) firstErr = e;
        var s = $('#slot-' + r.id);
        if (s) s.innerHTML = '';
        if (r.id === 'new') {
          var hero = $('#hero');
          if (hero) { hero.style.height = 'auto'; hero.style.minHeight = '0'; hero.innerHTML = '<div style="padding-top:110px">' + errHTML(e) + '</div>'; }
        }
      });
    };
  });
  pool(tasks, 3);
}

/* ---------------------------------------------------------------- Danh sách theo mục (lưới vô hạn) */
function openCategory(kind, key, title) {
  var pg = pushPage('cat');
  pg.innerHTML = '<div class="pagehead"><button class="iconbtn" data-act="back">' + ic('back') + '</button><h2>' + esc(title) + '</h2></div><div class="grid" id="g"></div><div class="loader-box"></div>';
  var box = $('.grid', pg);
  if (kind === 'mylist') {
    var l = getList();
    box.innerHTML = l.length ? l.map(function (m) { return cardHTML(m); }).join('') : '<div class="err" style="grid-column:1/-1"><div class="err-m">Danh sách của bạn đang trống.</div></div>';
    return;
  }
  makeFeed({ box: box, scroller: pg, kind: kind, key: key, alive: function () { return stack.indexOf(pg) >= 0; },
    render: function (items) { return items.map(function (m) { return cardHTML(m); }).join(''); } });
}

function makeFeed(o) {
  var page = 1, loading = false, done = false;
  var lb = document.createElement('div');
  o.box.parentNode.insertBefore(lb, o.box.nextSibling);
  function fill() {
    if (o.alive && !o.alive()) { done = true; return; }
    if (done || loading) return;
    var sc = o.scroller;
    if (sc.scrollTop + sc.clientHeight > sc.scrollHeight - 700) more();
  }
  function more() {
    if (o.alive && !o.alive()) { done = true; return; }
    if (loading || done) return;
    loading = true;
    lb.innerHTML = loaderHTML();
    fetchList(o.kind, o.key, page).then(function (r) {
      if (!r.items.length) { done = true; return; }
      var seen = o.box.__seen || (o.box.__seen = {});
      var fresh = r.items.filter(function (m) { if (seen[m.slug]) return false; seen[m.slug] = 1; return true; });
      if (fresh.length) o.box.insertAdjacentHTML('beforeend', o.render(fresh));
      page++;
      var tp = totalPages(r.pg);
      if (tp && page > tp) done = true;
      if (!fresh.length && r.items.length) done = true;
    }, function (e) {
      done = true;
      if (page === 1) lb.innerHTML = errHTML(e); else toast('Không tải thêm được');
    }).then(function () {
      loading = false;
      if (!(page === 1 && done)) lb.innerHTML = '';
      setTimeout(fill, 50);
    });
  }
  o.scroller.addEventListener('scroll', fill);
  more();
  return { more: more };
}

function openGenres() {
  fetchTaxonomy('/the-loai', FALLBACK_GENRES).then(function (g) {
    openSheet('Thể loại', g.map(function (x) {
      return '<button class="opt" data-act="more" data-kind="genre" data-key="' + esc(x.slug) + '" data-title="' + esc(x.name) + '">' + esc(x.name) + '</button>';
    }).join(''));
  });
}
function openCountries() {
  fetchTaxonomy('/quoc-gia', FALLBACK_COUNTRIES).then(function (g) {
    openSheet('Quốc gia', g.map(function (x) {
      return '<button class="opt" data-act="more" data-kind="country" data-key="' + esc(x.slug) + '" data-title="Phim ' + esc(x.name) + '">' + esc(x.name) + '</button>';
    }).join(''));
  });
}

/* ---------------------------------------------------------------- Chi tiết phim */
function epLabel(name) {
  name = String(name || '').trim();
  if (/^\d+$/.test(name)) return 'Tập ' + name;
  return name || 'Full';
}

function openDetail(slug) {
  var pg = pushPage('detail');
  var k = known[slug];
  pg.innerHTML = '<div class="dhero">' + (k ? pic(k.poster || k.thumb, k.thumb, 'l') : '') +
    '<button class="back" data-act="back">' + ic('back') + '</button></div><div class="dbody">' +
    (k ? '<h1>' + esc(k.name) + '</h1>' : '') + loaderHTML() + '</div>';
  fetchMovie(slug).then(function (d) {
    if (stack.indexOf(pg) < 0) return;
    renderDetail(pg, d);
  }, function (e) {
    if (stack.indexOf(pg) < 0) return;
    pg.innerHTML = '<div class="pagehead"><button class="iconbtn" data-act="back">' + ic('back') + '</button></div>' + errHTML(e);
  });
}

function resumeInfo(d) {
  var h = getHist()[d.movie.slug];
  var si = 0, ei = 0, resumed = false;
  if (h && d.servers[h.si] && d.servers[h.si].list[h.ei]) { si = h.si; ei = h.ei; resumed = true; }
  return { si: si, ei: ei, resumed: resumed };
}

function renderDetail(pg, d) {
  var m = d.movie;
  pg._ctx = { d: d, si: 0, tab: '' };
  var r = resumeInfo(d);
  pg._ctx.si = r.si;
  var multi = d.servers.length && d.servers[0].list.length > 1;
  var meta = [];
  if (m.year) meta.push('<span class="g">' + esc(m.year) + '</span>');
  if (m.quality) meta.push('<span class="tag">' + esc(m.quality) + '</span>');
  if (m.lang) meta.push('<span>' + esc(m.lang) + '</span>');
  if (m.time) meta.push('<span>' + esc(m.time) + '</span>');
  if (m.ep) meta.push('<span>' + esc(m.ep) + (m.total && /^\d+$/.test(m.total) ? ' / ' + esc(m.total) : '') + '</span>');
  var playLbl = 'Phát';
  var sub = '';
  if (d.servers.length) {
    var e0 = d.servers[r.si].list[r.ei];
    if (multi) sub = (r.resumed ? 'Tiếp tục ' : '') + epLabel(e0.name);
  }
  var cats = m.category.map(function (c) { return c.name; }).filter(Boolean);
  pg.innerHTML =
    '<div class="dhero">' + pic(m.poster || m.thumb, m.thumb, 'l') +
    '<button class="back" data-act="back">' + ic('back') + '</button>' +
    (d.servers.length ? '<button class="fab" data-act="play-main">' + ic('play', 34) + '</button>' : '') + '</div>' +
    '<div class="dbody"><h1>' + esc(m.name) + '</h1>' + (m.origin ? '<div class="origin">' + esc(m.origin) + '</div>' : '') +
    '<div class="meta">' + meta.join('') + '</div>' +
    (d.servers.length
      ? '<button class="btn-play" data-act="play-main">' + ic('play', 26) + playLbl + (sub ? ' <small>' + esc(sub) + '</small>' : '') + '</button>'
      : '<div class="err-m" style="text-align:center">Phim này chưa có tập nào để phát.</div>') +
    (m.content ? '<p class="desc clamp" data-act="expand">' + esc(m.content) + '</p>' : '') +
    (m.actor.length ? '<div class="cast"><b>Diễn viên:</b> ' + esc(m.actor.slice(0, 6).join(', ')) + (m.actor.length > 6 ? '…' : '') + '</div>' : '') +
    (cats.length ? '<div class="cast"><b>Thể loại:</b> ' + esc(cats.join(', ')) + '</div>' : '') +
    '<div class="actions">' +
    '<button class="act' + (inList(m.slug) ? ' on' : '') + '" data-act="toggle-list">' + ic(inList(m.slug) ? 'check' : 'plus', 28) + '<span>Danh sách</span></button>' +
    '<button class="act' + (isLiked(m.slug) ? ' on' : '') + '" data-act="like">' + ic('like', 26) + '<span>' + (isLiked(m.slug) ? 'Đã thích' : 'Thích') + '</span></button>' +
    '<button class="act" data-act="share">' + ic('share', 26) + '<span>Chia sẻ</span></button></div>' +
    '<div class="dtabs">' + (multi ? '<button data-act="dtab" data-t="eps">Các tập</button>' : '') +
    '<button data-act="dtab" data-t="more">Tương tự</button><button data-act="dtab" data-t="info">Thông tin</button></div>' +
    '<div class="dtab-body"></div></div>';
  setDetailTab(pg, multi ? 'eps' : 'more');
}

function setDetailTab(pg, t) {
  var c = pg._ctx;
  c.tab = t;
  $$('.dtabs button', pg).forEach(function (b) { b.classList.toggle('on', b.getAttribute('data-t') === t); });
  var body = $('.dtab-body', pg);
  var m = c.d.movie;
  if (t === 'eps') {
    var html = '';
    if (c.d.servers.length > 1) {
      html += '<div class="servers">' + c.d.servers.map(function (s, i) {
        return '<button class="chip' + (i === c.si ? ' on' : '') + '" data-act="server" data-i="' + i + '">' + esc(s.name) + '</button>';
      }).join('') + '</div>';
    }
    var sv = c.d.servers[c.si];
    var h = getHist()[m.slug];
    html += sv.list.map(function (e, i) {
      var cur = h && h.si === c.si && h.ei === i;
      return '<div class="ep' + (cur ? ' cur' : '') + '" data-act="play-ep" data-i="' + i + '"><div class="n">' + (i + 1) + '</div>' +
        '<div class="t"><b>' + esc(epLabel(e.name)) + '</b><span>' + esc(m.name) + (cur ? ' • đang xem dở' : '') + '</span></div>' + ic('play', 26) + '</div>';
    }).join('');
    body.innerHTML = html;
  } else if (t === 'more') {
    body.innerHTML = loaderHTML();
    var ck = m.category[0], cc = m.country[0];
    var p = ck ? fetchList('genre', ck.slug, 1) : (cc ? fetchList('country', cc.slug, 1) : Promise.resolve({ items: [] }));
    p.then(function (r) {
      var items = r.items.filter(function (x) { return x.slug !== m.slug; }).slice(0, 18);
      if (!items.length && cc && ck) return fetchList('country', cc.slug, 1).then(function (r2) { return r2.items.filter(function (x) { return x.slug !== m.slug; }).slice(0, 18); });
      return items;
    }).then(function (items) {
      if (c.tab !== 'more' || !body.parentNode) return;
      body.innerHTML = items.length ? '<div class="grid" style="padding:10px 0">' + items.map(function (x) { return cardHTML(x); }).join('') + '</div>'
        : '<div class="err-m" style="padding:20px 0;text-align:center">Chưa có gợi ý.</div>';
    }, function () {
      if (c.tab === 'more') body.innerHTML = '<div class="err-m" style="padding:20px 0;text-align:center">Không tải được gợi ý.</div>';
    });
  } else {
    var h2 = '';
    if (m.director.length) h2 += '<div class="cast"><b>Đạo diễn:</b> ' + esc(m.director.join(', ')) + '</div>';
    if (m.actor.length) h2 += '<div class="cast"><b>Diễn viên:</b> ' + esc(m.actor.join(', ')) + '</div>';
    if (m.category.length) h2 += '<div class="cast" style="margin-top:14px"><b>Thể loại</b></div><div style="margin-top:6px">' + m.category.map(function (x) {
      return '<a class="tagc" data-act="more" data-kind="genre" data-key="' + esc(x.slug) + '" data-title="' + esc(x.name) + '">' + esc(x.name) + '</a>';
    }).join('') + '</div>';
    if (m.country.length) h2 += '<div class="cast"><b>Quốc gia</b></div><div style="margin-top:6px">' + m.country.map(function (x) {
      return '<a class="tagc" data-act="more" data-kind="country" data-key="' + esc(x.slug) + '" data-title="Phim ' + esc(x.name) + '">' + esc(x.name) + '</a>';
    }).join('') + '</div>';
    body.innerHTML = h2 || '<div class="err-m" style="padding:20px 0;text-align:center">Chưa có thông tin.</div>';
  }
}

/* ---------------------------------------------------------------- Phát phim */
var lastPlay = null;

function startPlay(d, si, ei) {
  var m = d.movie;
  var sv = d.servers[si];
  if (!sv || !sv.list[ei]) { toast('Không có tập để phát'); return; }
  var e = sv.list[ei];
  if (!e.embed && !e.m3u8) { toast('Tập này chưa có nguồn phát'); return; }
  lastPlay = { d: d, si: si };
  saveHist(m, si, ei, epLabel(e.name), sv.list.length);
  var payload = {
    title: m.name, slug: m.slug, index: ei,
    episodes: sv.list.map(function (x) { return { name: epLabel(x.name), embed: x.embed, m3u8: x.m3u8 }; })
  };
  if (window.Android && window.Android.play) window.Android.play(JSON.stringify(payload));
  else window.open(e.embed || e.m3u8, '_blank');
}
window.__onEpisode = function (i) {
  if (!lastPlay) return;
  var sv = lastPlay.d.servers[lastPlay.si];
  if (!sv || !sv.list[i]) return;
  saveHist(lastPlay.d.movie, lastPlay.si, i, epLabel(sv.list[i].name), sv.list.length);
};

function quickPlay(slug) {
  toast('Đang mở phim...');
  fetchMovie(slug).then(function (d) {
    if (!d.servers.length) { toast('Phim này chưa có tập nào'); openDetail(slug); return; }
    var r = resumeInfo(d);
    startPlay(d, r.si, r.ei);
  }, function (e) { toast('Lỗi: ' + (e && e.message ? e.message : e)); });
}

/* ---------------------------------------------------------------- Tìm kiếm */
var searchTimer = null, searchSeq = 0;

function initSearch() {
  $('#tab-search').innerHTML =
    '<div class="sbar"><div class="sbox">' + ic('search', 22) +
    '<input id="q" type="search" placeholder="Tìm phim, diễn viên, thể loại" autocomplete="off">' +
    '<button data-act="clearq" id="clearq" class="hidden">' + ic('close', 20) + '</button></div></div><div id="sres"></div>';
  var q = $('#q');
  q.addEventListener('input', function () {
    var v = q.value.trim();
    $('#clearq').classList.toggle('hidden', !q.value);
    clearTimeout(searchTimer);
    searchTimer = setTimeout(function () { runSearch(v); }, 420);
  });
  q.addEventListener('keydown', function (e) { if (e.key === 'Enter') { clearTimeout(searchTimer); runSearch(q.value.trim()); q.blur(); } });
  renderSearchIdle();
  setTimeout(function () { q.focus(); }, 150);
}

function liHTML(m) {
  return '<a class="li" data-act="open" data-slug="' + esc(m.slug) + '"><div class="th">' + pic(m.poster || m.thumb, m.thumb, 'l') + '</div>' +
    '<div class="tx">' + esc(m.name) + '<span>' + esc([m.year, m.ep || m.quality].filter(Boolean).join(' • ')) + '</span></div>' +
    '<div class="pl">' + ic('play', 22) + '</div></a>';
}

function renderSearchIdle() {
  var box = $('#sres');
  if (!box) return;
  var q = $('#q');
  if (q && q.value.trim().length >= 2) return;
  var rec = getRecent();
  var html = '';
  if (rec.length) {
    html += '<div class="sec-t">Tìm kiếm gần đây</div><div class="recent">' + rec.map(function (r) {
      return '<a class="tagc" data-act="recent" data-q="' + esc(r) + '">' + esc(r) + '</a>';
    }).join('') + '</div>';
  }
  html += '<div class="sec-t">Phim đang được quan tâm</div><div id="sugg">' + loaderHTML() + '</div>';
  box.innerHTML = html;
  fetchList('list', 'phim-moi-cap-nhat', 1).then(function (r) {
    var s = $('#sugg');
    if (s) s.innerHTML = r.items.slice(0, 14).map(liHTML).join('');
  }, function (e) {
    var s = $('#sugg');
    if (s) s.innerHTML = errHTML(e);
  });
}

function runSearch(v) {
  var box = $('#sres');
  if (!box) return;
  if (v.length < 2) { renderSearchIdle(); return; }
  var my = ++searchSeq;
  box.innerHTML = '<div class="sec-t">Kết quả cho "' + esc(v) + '"</div>' + loaderHTML();
  fetchList('search', v, 1).then(function (r) {
    if (my !== searchSeq) return;
    addRecent(v);
    box.innerHTML = '<div class="sec-t">Kết quả cho "' + esc(v) + '"</div>' +
      (r.items.length ? '<div class="grid" id="sgrid">' + r.items.map(function (m) { return cardHTML(m); }).join('') + '</div>'
        : '<div class="err"><div class="err-m">Không tìm thấy phim phù hợp.</div></div>');
  }, function (e) {
    if (my !== searchSeq) return;
    box.innerHTML = errHTML(e);
  });
}

/* ---------------------------------------------------------------- Mới & Hot */
function hotItem(m) {
  return '<div class="hot-i"><div class="pic" data-act="open" data-slug="' + esc(m.slug) + '">' + pic(m.poster || m.thumb, m.thumb, 'l') +
    (m.ep || m.quality ? '<span class="bdg">' + esc(m.ep || m.quality) + '</span>' : '') + '</div>' +
    '<div class="bd"><div style="min-width:0"><b>' + esc(m.name) + '</b><span>' + esc([m.origin, m.year, m.lang].filter(Boolean).join(' • ')) + '</span></div>' +
    '<div class="acts"><button data-act="addmini" data-slug="' + esc(m.slug) + '">' + ic(inList(m.slug) ? 'check' : 'plus', 24) + '<span>Danh sách</span></button>' +
    '<button data-act="quickplay" data-slug="' + esc(m.slug) + '">' + ic('play', 24) + '<span>Phát</span></button></div></div></div>';
}
var hotKind = 'phim-moi-cap-nhat';
function initHot() {
  var el = $('#tab-hot');
  el.innerHTML = '<div class="pagehead"><h2>Mới & Hot</h2></div>' +
    '<div class="chips" style="padding:0 12px 12px">' +
    [['phim-moi-cap-nhat', '🔥 Mới cập nhật'], ['phim-bo', '📺 Phim bộ'], ['phim-le', '🎬 Phim lẻ'], ['hoat-hinh', '✨ Hoạt hình'], ['subteam', '💬 Vietsub độc quyền']].map(function (x) {
      return '<button class="chip' + (x[0] === hotKind ? ' on' : '') + '" data-act="hotkind" data-k="' + x[0] + '">' + x[1] + '</button>';
    }).join('') + '</div><div id="hotbox"></div>';
  loadHot();
}
var hotFeedToken = 0;
function loadHot() {
  var box = $('#hotbox');
  box.innerHTML = '';
  var old = box.nextSibling;
  while (old) { var nx = old.nextSibling; old.parentNode.removeChild(old); old = nx; }
  var tok = ++hotFeedToken;
  var scroller = $('#tab-hot');
  var feed = makeFeed({ box: box, scroller: scroller, kind: 'list', key: hotKind, alive: function () { return tok === hotFeedToken; },
    render: function (items) { return items.map(hotItem).join(''); } });
  return feed;
}

/* ---------------------------------------------------------------- Của tôi */
function renderMine() {
  var el = $('#tab-mine');
  if (!me) return;
  var l = getList(), h = histArr();
  el.innerHTML =
    '<div class="mine-h"><div class="av" style="background:' + COLORS[me.c % COLORS.length] + '">' + FACES[me.c % FACES.length] + '</div><h2>' + esc(me.name) + '</h2></div>' +
    '<div class="menu">' +
    '<button data-act="more" data-kind="mylist" data-key="x" data-title="Danh sách của tôi">' + ic('list') + '<span>Danh sách của tôi</span><small>' + l.length + ' phim</small></button>' +
    '<button data-act="profiles">' + ic('swap') + '<span>Đổi hồ sơ</span></button>' +
    '<button data-act="api-setting">' + ic('gear') + '<span>Địa chỉ API</span></button>' +
    '<button data-act="clear-hist">' + ic('trash') + '<span>Xóa lịch sử xem</span><small>' + h.length + ' phim</small></button>' +
    '<button data-act="clear-cache">' + ic('trash') + '<span>Xóa bộ nhớ đệm</span></button>' +
    '<button data-act="about">' + ic('info') + '<span>Giới thiệu</span></button></div>' +
    (h.length ? '<div class="sec-t">Lịch sử xem</div>' + h.slice(0, 20).map(function (x) { return liHTML(x.m).replace('</span></div><div class="pl">', ' • ' + esc(x.epName || '') + '</span></div><div class="pl">'); }).join('') : '') +
    '<div style="height:30px"></div>';
}

/* ---------------------------------------------------------------- Hồ sơ */
var manageMode = false;
function showProfiles() {
  var p = $('#profiles');
  p.classList.remove('hidden');
  var html = '<h1>' + (manageMode ? 'Quản lý hồ sơ' : 'Ai đang xem?') + '</h1><div class="pf-grid">' + profiles.map(function (pf) {
    return '<div class="pf" data-act="' + (manageMode ? 'pf-edit' : 'pf-pick') + '" data-id="' + esc(pf.id) + '"><div class="av" style="background:' + COLORS[pf.c % COLORS.length] + '">' +
      FACES[pf.c % FACES.length] + '</div><div class="nm">' + esc(pf.name) + '</div>' + (manageMode ? '<div class="edit">✎</div>' : '') + '</div>';
  }).join('') + (profiles.length < 5 ? '<div class="pf add" data-act="pf-add"><div class="av">+</div><div class="nm">Thêm hồ sơ</div></div>' : '') +
    '</div><button class="pf-manage" data-act="pf-manage">' + (manageMode ? 'XONG' : 'QUẢN LÝ HỒ SƠ') + '</button>';
  p.innerHTML = html;
  $('#main').classList.add('hidden');
  while (stack.length) popPage(true);
}
function enterProfile(id) {
  me = profiles.filter(function (x) { return x.id === id; })[0] || profiles[0];
  Store.set('lastProfile', me.id);
  manageMode = false;
  $('#profiles').classList.add('hidden');
  $('#main').classList.remove('hidden');
  tabInit = {};
  $('#tab-hot').innerHTML = '';
  $('#tab-search').innerHTML = '';
  curTab = 'home';
  $$('.tab').forEach(function (t) { t.classList.toggle('on', t.id === 'tab-home'); });
  renderTabbar();
  renderHome();
}

/* ---------------------------------------------------------------- xử lý bấm (event delegation) */
document.addEventListener('click', function (ev) {
  var t = ev.target.closest ? ev.target.closest('[data-act]') : null;
  if (!t) return;
  var act = t.getAttribute('data-act');
  var page = t.closest ? t.closest('.page') : null;
  var ctx = page ? page._ctx : null;

  switch (act) {
    case 'tab': closeSheet(); switchTab(t.getAttribute('data-tab')); break;
    case 'open': openDetail(t.getAttribute('data-slug')); break;
    case 'back': popPage(); break;
    case 'more':
      closeSheet();
      openCategory(t.getAttribute('data-kind'), t.getAttribute('data-key'), t.getAttribute('data-title'));
      break;
    case 'genres': openGenres(); break;
    case 'countries': openCountries(); break;
    case 'reload': location.reload(); break;
    case 'quickplay': ev.stopPropagation(); quickPlay(t.getAttribute('data-slug')); break;
    case 'heroadd':
      ev.stopPropagation();
      if (heroMovie) { var added = toggleList(heroMovie); t.innerHTML = ic(added ? 'check' : 'plus', 22) + 'Danh sách'; refreshLocalRows(); }
      break;
    case 'addmini':
      var mm = known[t.getAttribute('data-slug')];
      if (mm) { var ad = toggleList(mm); t.innerHTML = ic(ad ? 'check' : 'plus', 24) + '<span>Danh sách</span>'; }
      break;
    case 'expand': t.classList.toggle('clamp'); break;
    case 'play-main':
      if (ctx) { var r = resumeInfo(ctx.d); if (r.resumed) startPlay(ctx.d, r.si, r.ei); else startPlay(ctx.d, ctx.si, 0); }
      break;
    case 'play-ep': if (ctx) { startPlay(ctx.d, ctx.si, Number(t.getAttribute('data-i'))); setTimeout(function () { if (stack.indexOf(page) >= 0) setDetailTab(page, 'eps'); }, 300); } break;
    case 'server': if (ctx) { ctx.si = Number(t.getAttribute('data-i')); setDetailTab(page, 'eps'); } break;
    case 'dtab': if (ctx) setDetailTab(page, t.getAttribute('data-t')); break;
    case 'toggle-list':
      if (ctx) {
        var on = toggleList(ctx.d.movie);
        t.classList.toggle('on', on);
        t.innerHTML = ic(on ? 'check' : 'plus', 28) + '<span>Danh sách</span>';
      }
      break;
    case 'like':
      if (ctx) {
        var lk = toggleLike(ctx.d.movie.slug);
        t.classList.toggle('on', lk);
        t.innerHTML = ic('like', 26) + '<span>' + (lk ? 'Đã thích' : 'Thích') + '</span>';
        if (lk) toast('Cảm ơn! Đã ghi nhận bạn thích phim này');
      }
      break;
    case 'share':
      if (ctx) {
        var txt = 'Xem phim "' + ctx.d.movie.name + '": ' + ORIGIN + '/phim/' + ctx.d.movie.slug;
        if (window.Android && window.Android.share) window.Android.share(txt); else toast(txt);
      }
      break;
    case 'recent': var rq = t.getAttribute('data-q'); $('#q').value = rq; $('#clearq').classList.remove('hidden'); runSearch(rq); break;
    case 'clearq': $('#q').value = ''; $('#clearq').classList.add('hidden'); renderSearchIdle(); $('#q').focus(); break;
    case 'hotkind':
      hotKind = t.getAttribute('data-k');
      $$('#tab-hot .chip').forEach(function (c) { c.classList.toggle('on', c === t); });
      $('#tab-hot').scrollTop = 0;
      loadHot();
      break;
    case 'profiles': closeSheet(); showProfiles(); break;
    case 'pf-pick': enterProfile(t.getAttribute('data-id')); break;
    case 'pf-manage': manageMode = !manageMode; showProfiles(); break;
    case 'pf-add':
      ask({ title: 'Thêm hồ sơ', input: true, value: 'Hồ sơ ' + (profiles.length + 1), ok: 'Tạo' }).then(function (v) {
        if (v == null) return;
        v = String(v).trim() || ('Hồ sơ ' + (profiles.length + 1));
        var id = 'p' + Date.now();
        profiles.push({ id: id, name: v.slice(0, 16), c: profiles.length % COLORS.length });
        Store.set('profiles', profiles);
        showProfiles();
      });
      break;
    case 'pf-edit':
      var pid = t.getAttribute('data-id');
      var pf = profiles.filter(function (x) { return x.id === pid; })[0];
      if (!pf) break;
      ask({ title: 'Sửa hồ sơ', input: true, value: pf.name, ok: 'Lưu', cancel: profiles.length > 1 ? 'Xóa hồ sơ' : 'Hủy' }).then(function (v) {
        if (v == null) {
          if (profiles.length > 1) {
            profiles = profiles.filter(function (x) { return x.id !== pid; });
            Store.set('profiles', profiles);
            showProfiles();
          }
          return;
        }
        pf.name = String(v).trim().slice(0, 16) || pf.name;
        Store.set('profiles', profiles);
        showProfiles();
      });
      break;
    case 'dlg-ok': if (dialogResolve) dialogResolve(true); break;
    case 'dlg-no': if (dialogResolve) dialogResolve(false); break;
    case 'api-setting':
      ask({ title: 'Địa chỉ API', text: 'Mặc định: ' + DEFAULT_BASE + ' (để trống để dùng mặc định)', input: true, value: apiBase(), ok: 'Lưu' }).then(function (v) {
        if (v == null) return;
        v = String(v).trim();
        Store.set('apiBase', v && v !== DEFAULT_BASE ? v : '');
        cache = {}; goodPattern = {};
        toast('Đã lưu. Đang tải lại...');
        setTimeout(function () { location.reload(); }, 600);
      });
      break;
    case 'clear-hist':
      ask({ title: 'Xóa lịch sử xem?', text: 'Hành động này không thể hoàn tác.', ok: 'Xóa' }).then(function (ok) {
        if (ok) { Store.set(pk('hist'), {}); toast('Đã xóa lịch sử'); renderMine(); }
      });
      break;
    case 'clear-cache': cache = {}; toast('Đã xóa bộ nhớ đệm'); break;
    case 'about':
      ask({ title: 'VSMovie', text: 'Ứng dụng xem phim, dữ liệu lấy từ API của vsmov.com. Giao diện lấy cảm hứng từ Netflix.' + (hasNative() && window.Android.version ? ' Phiên bản ' + window.Android.version() : ''), ok: 'Đóng', cancel: false });
      break;
    default: break;
  }
});
document.addEventListener('click', function (ev) {
  // bấm vào nền tối của bottom sheet để đóng
  if (ev.target && ev.target.id === 'sheet') closeSheet();
});

/* ---------------------------------------------------------------- khởi động */
function boot() {
  var splash = $('#splash');
  setTimeout(function () {
    splash.classList.add('out');
    setTimeout(function () { splash.parentNode && splash.parentNode.removeChild(splash); }, 600);
  }, 1100);
  if (profiles.length === 1) enterProfile(profiles[0].id);
  else showProfiles();
}

window.__vs = { fetchList: fetchList, fetchMovie: fetchMovie, pickList: pickList, normMovie: normMovie, boot: boot, getJSON: getJSON };
if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', boot); else boot();
})();
