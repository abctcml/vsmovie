#!/usr/bin/env bash
# Chạy trên GitHub Actions: kiểm tra API (chỉ in log) rồi build APK.
set -e
cd "$(dirname "$0")/.."

echo "=============== KIỂM TRA API VSMOV (chỉ để xem log) ==============="
for u in \
  "https://vsmov.com/api/danh-sach/phim-moi-cap-nhat?page=1" \
  "https://vsmov.com/api/the-loai" \
  "https://vsmov.com/api/quoc-gia" \
  "https://vsmov.com/api/tim-kiem?keyword=avengers&limit=2"; do
  echo "--- $u"
  curl -sS -m 25 -A "Mozilla/5.0" "$u" | head -c 700 || true
  echo
done
echo "=============== BUILD APK ==============="

gradle assembleDebug --no-daemon --stacktrace
cp app/build/outputs/apk/debug/app-debug.apk "$GITHUB_WORKSPACE/VSMovie.apk"
echo "Đã tạo VSMovie.apk"
